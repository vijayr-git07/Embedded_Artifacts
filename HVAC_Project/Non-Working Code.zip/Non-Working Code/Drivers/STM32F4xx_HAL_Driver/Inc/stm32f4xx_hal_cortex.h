#ifndef __STM32F4xx_HAL_CORTEX_H
#define __STM32F4xx_HAL_CORTEX_H

#include "stm32f4xx_hal_def.h"

#endif /* __STM32F4xx_HAL_CORTEX_H */