#ifndef __STM32F4xx_HAL_RCC_H
#define __STM32F4xx_HAL_RCC_H

#include "stm32f4xx_hal_def.h"

void __HAL_RCC_SYSCFG_CLK_ENABLE(void);
void __HAL_RCC_PWR_CLK_ENABLE(void);
void __HAL_RCC_ADC1_CLK_ENABLE(void);
void __HAL_RCC_GPIOA_CLK_ENABLE(void);
void __HAL_RCC_GPIOB_CLK_ENABLE(void);
void __HAL_RCC_GPIOC_CLK_ENABLE(void);
void __HAL_RCC_TIM3_CLK_ENABLE(void);
void __HAL_RCC_USART2_CLK_ENABLE(void);

#endif /* __STM32F4xx_HAL_RCC_H */