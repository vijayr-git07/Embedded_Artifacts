#ifndef __STM32F4xx_HAL_DEF_H
#define __STM32F4xx_HAL_DEF_H

#include <stdint.h>
#include <stddef.h>

#define HAL_OK       0x00U
#define HAL_ERROR    0x01U
#define HAL_BUSY     0x02U
#define HAL_TIMEOUT  0x03U

typedef uint32_t HAL_StatusTypeDef;

#endif /* __STM32F4xx_HAL_DEF_H */