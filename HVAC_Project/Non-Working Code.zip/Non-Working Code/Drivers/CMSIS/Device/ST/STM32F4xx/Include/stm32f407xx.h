#ifndef __STM32F407XX_H
#define __STM32F407XX_H

#include <stdint.h>

#define PERIPH_BASE           ((uint32_t)0x40000000)
#define AHB1PERIPH_BASE       (PERIPH_BASE + 0x00020000)
#define GPIOA_BASE            (AHB1PERIPH_BASE + 0x0000)
#define GPIOB_BASE            (AHB1PERIPH_BASE + 0x0400)
#define GPIOC_BASE            (AHB1PERIPH_BASE + 0x0800)
#define ADC1_BASE             (PERIPH_BASE + 0x20000)
#define TIM3_BASE             (PERIPH_BASE + 0x04000)
#define USART2_BASE           (PERIPH_BASE + 0x4400)

#define GPIOA                 ((GPIO_TypeDef *) GPIOA_BASE)
#define GPIOB                 ((GPIO_TypeDef *) GPIOB_BASE)
#define GPIOC                 ((GPIO_TypeDef *) GPIOC_BASE)
#define ADC1                  ((ADC_TypeDef *) ADC1_BASE)
#define TIM3                  ((TIM_TypeDef *) TIM3_BASE)
#define USART2                ((USART_TypeDef *) USART2_BASE)

#define FLASH_BASE            0x08000000UL
#define SRAM_BASE             0x20000000UL

#endif /* __STM32F407XX_H */