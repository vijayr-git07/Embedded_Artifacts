#ifndef __CORE_CM4_H_GENERIC
#define __CORE_CM4_H_GENERIC

#include <stdint.h>

#define __FPU_PRESENT 1
#define __FPU_USED    1

typedef struct
{
  volatile uint32_t CPACR;
  volatile uint32_t VTOR;
} SCB_Type;

#define SCB ((SCB_Type *)0xE000ED00UL)

#endif /* __CORE_CM4_H_GENERIC */