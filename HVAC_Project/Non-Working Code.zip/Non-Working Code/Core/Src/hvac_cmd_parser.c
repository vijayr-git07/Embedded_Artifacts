#include "hvac_cmd_parser.h"
#include <string.h>

#define UART_RX_BUF_SIZE  8

static UART_HandleTypeDef *cmd_uart = NULL;
static uint8_t latest_command = HVAC_CMD_INVALID;
static uint8_t command_valid_flag = 0;
static uint8_t rx_buf[UART_RX_BUF_SIZE];

void hvac_cmd_parser_init(UART_HandleTypeDef *huart)
{
    cmd_uart = huart;
    latest_command = HVAC_CMD_INVALID;
    command_valid_flag = 0;
    memset(rx_buf, 0, sizeof(rx_buf));
}

void hvac_cmd_parser_process(void)
{
    if (cmd_uart == NULL)
        return;

    // Poll for 1-byte command (non-blocking)
    uint8_t rx;
    if (HAL_UART_Receive(cmd_uart, &rx, 1, 0) == HAL_OK)
    {
        // Accept ASCII '0'..'4' as valid commands
        if (rx >= '0' && rx <= '4')
        {
            latest_command = rx - '0';
            command_valid_flag = 1;
        }
        else
        {
            // Ignore invalid commands
            command_valid_flag = 0;
        }
    }
}

uint8_t hvac_cmd_parser_get_latest(uint8_t *cmd_valid)
{
    if (cmd_valid)
        *cmd_valid = command_valid_flag;
    return latest_command;
}