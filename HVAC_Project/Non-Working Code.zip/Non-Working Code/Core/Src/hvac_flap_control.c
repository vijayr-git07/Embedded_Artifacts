#include "hvac_flap_control.h"
#include "hvac_cmd_parser.h"
#include "hvac_feedback.h"
#include "hvac_motor_driver.h"
#include "hvac_led_status.h"

#define FLAP_POS_TOLERANCE 0 // Only exact match accepted

static uint8_t target_position = HVAC_FLAP_POS_INVALID;
static uint8_t movement_active_flag = 0;

void hvac_flap_control_init(void)
{
    target_position = HVAC_FLAP_POS_INVALID;
    movement_active_flag = 0;
}

void hvac_flap_control_set_target(uint8_t target_pos)
{
    target_position = target_pos;
}

void hvac_flap_control_process(void)
{
    uint8_t cmd_valid = 0;
    uint8_t cmd = hvac_cmd_parser_get_latest(&cmd_valid);

    uint8_t feedback_valid = 0;
    uint8_t current_pos = hvac_feedback_get_position(&feedback_valid);

    // Fault: invalid feedback disables motor
    if (!feedback_valid)
    {
        hvac_motor_driver_stop();
        movement_active_flag = 0;
        // Do not update LEDs on invalid feedback
        return;
    }

    // Accept new command if valid and different from current target
    if (cmd_valid && cmd <= 4 && cmd != target_position)
    {
        target_position = cmd;
    }

    // If no valid target, do nothing
    if (target_position == HVAC_FLAP_POS_INVALID)
    {
        hvac_motor_driver_stop();
        movement_active_flag = 0;
        return;
    }

    // If already at target, stop motor and update LED
    if (current_pos == target_position)
    {
        if (movement_active_flag)
        {
            hvac_motor_driver_stop();
            movement_active_flag = 0;
            hvac_led_status_update(current_pos, 1);
        }
        return;
    }

    // Move toward target
    if (current_pos < target_position)
    {
        hvac_motor_driver_set_direction(MOTOR_DIR_CW);
        hvac_motor_driver_enable(1);
        movement_active_flag = 1;
    }
    else if (current_pos > target_position)
    {
        hvac_motor_driver_set_direction(MOTOR_DIR_CCW);
        hvac_motor_driver_enable(1);
        movement_active_flag = 1;
    }
}