#include "hvac_led_status.h"

static GPIO_TypeDef *led_power_port = NULL;
static uint16_t led_power_pin = 0;
static GPIO_TypeDef *led_pos_ports[5] = {0};
static uint16_t led_pos_pins[5] = {0};
static uint8_t current_led_state = 0xFF;

void hvac_led_status_init(GPIO_TypeDef *power_port, uint16_t power_pin,
                         GPIO_TypeDef *pos_ports[5], uint16_t pos_pins[5])
{
    led_power_port = power_port;
    led_power_pin = power_pin;
    for (uint8_t i = 0; i < 5; ++i)
    {
        led_pos_ports[i] = pos_ports[i];
        led_pos_pins[i] = pos_pins[i];
    }
    current_led_state = 0xFF;

    // Power LED ON
    HAL_GPIO_WritePin(led_power_port, led_power_pin, GPIO_PIN_SET);

    // All position LEDs OFF
    for (uint8_t i = 0; i < 5; ++i)
        HAL_GPIO_WritePin(led_pos_ports[i], led_pos_pins[i], GPIO_PIN_RESET);
}

void hvac_led_status_update(uint8_t flap_position, uint8_t valid)
{
    if (!valid)
        return; // Do not update on invalid feedback

    if (flap_position > 4)
        return;

    if (flap_position == current_led_state)
        return; // No change

    // Turn off all position LEDs
    for (uint8_t i = 0; i < 5; ++i)
        HAL_GPIO_WritePin(led_pos_ports[i], led_pos_pins[i], GPIO_PIN_RESET);

    // Turn on only the current position LED
    HAL_GPIO_WritePin(led_pos_ports[flap_position], led_pos_pins[flap_position], GPIO_PIN_SET);

    current_led_state = flap_position;
}