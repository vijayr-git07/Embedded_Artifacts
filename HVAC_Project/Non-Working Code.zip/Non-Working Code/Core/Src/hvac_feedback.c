#include "hvac_feedback.h"
#include "hvac_bsp.h"

typedef struct {
    uint16_t min;
    uint16_t max;
} adc_range_t;

static ADC_HandleTypeDef *feedback_adc = NULL;
static uint16_t latest_adc_value = 0;
static uint8_t current_flap_position = HVAC_FLAP_POS_INVALID;
static uint8_t feedback_valid_flag = 0;

// ADC boundaries for 5 positions
static const adc_range_t adc_ranges[5] = {
    {HVAC_ADC_POS0_MIN, HVAC_ADC_POS0_MAX},
    {HVAC_ADC_POS1_MIN, HVAC_ADC_POS1_MAX},
    {HVAC_ADC_POS2_MIN, HVAC_ADC_POS2_MAX},
    {HVAC_ADC_POS3_MIN, HVAC_ADC_POS3_MAX},
    {HVAC_ADC_POS4_MIN, HVAC_ADC_POS4_MAX}
};

void hvac_feedback_init(ADC_HandleTypeDef *hadc)
{
    feedback_adc = hadc;
    latest_adc_value = 0;
    current_flap_position = HVAC_FLAP_POS_INVALID;
    feedback_valid_flag = 0;
}

void hvac_feedback_update(void)
{
    if (feedback_adc == NULL)
        return;

    HAL_ADC_Start(feedback_adc);
    if (HAL_ADC_PollForConversion(feedback_adc, 10) == HAL_OK)
    {
        uint16_t adc_val = (uint16_t)HAL_ADC_GetValue(feedback_adc);
        latest_adc_value = adc_val;
        feedback_valid_flag = 0;
        current_flap_position = HVAC_FLAP_POS_INVALID;

        // Map ADC value to logical position
        for (uint8_t i = 0; i < 5; ++i)
        {
            if (adc_val >= adc_ranges[i].min && adc_val <= adc_ranges[i].max)
            {
                current_flap_position = i;
                feedback_valid_flag = 1;
                break;
            }
        }
    }
    HAL_ADC_Stop(feedback_adc);
}

uint8_t hvac_feedback_get_position(uint8_t *valid)
{
    if (valid)
        *valid = feedback_valid_flag;
    return current_flap_position;
}