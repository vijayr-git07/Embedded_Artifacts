#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f4xx_hal.h"

// Peripheral handles (to be defined in main.c or CubeMX-generated code)
extern UART_HandleTypeDef huart2;
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;

#endif /* __MAIN_H */