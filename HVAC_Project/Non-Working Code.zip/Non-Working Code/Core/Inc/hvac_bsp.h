#ifndef HVAC_BSP_H
#define HVAC_BSP_H

#include "stm32f4xx_hal.h"

// UART
#define HVAC_UART_INSTANCE         USART2
#define HVAC_UART_BAUDRATE        115200

// ADC
#define HVAC_ADC_INSTANCE         ADC1
#define HVAC_ADC_CHANNEL          ADC_CHANNEL_1

// Motor Direction GPIOs
#define HVAC_MOTOR_DIR_PORT       GPIOB
#define HVAC_MOTOR_DIR_PIN_CW     GPIO_PIN_0
#define HVAC_MOTOR_DIR_PIN_CCW    GPIO_PIN_1

// Motor PWM
#define HVAC_MOTOR_PWM_TIM        TIM3
#define HVAC_MOTOR_PWM_CHANNEL    TIM_CHANNEL_1

// LED GPIOs
#define HVAC_LED_POWER_PORT       GPIOC
#define HVAC_LED_POWER_PIN        GPIO_PIN_13

#define HVAC_LED_POS0_PORT        GPIOC
#define HVAC_LED_POS0_PIN         GPIO_PIN_0
#define HVAC_LED_POS1_PORT        GPIOC
#define HVAC_LED_POS1_PIN         GPIO_PIN_1
#define HVAC_LED_POS2_PORT        GPIOC
#define HVAC_LED_POS2_PIN         GPIO_PIN_2
#define HVAC_LED_POS3_PORT        GPIOC
#define HVAC_LED_POS3_PIN         GPIO_PIN_3
#define HVAC_LED_POS4_PORT        GPIOC
#define HVAC_LED_POS4_PIN         GPIO_PIN_4

// ADC Flap Position Boundaries (example values, 12-bit ADC)
#define HVAC_ADC_POS0_MIN     0
#define HVAC_ADC_POS0_MAX     819
#define HVAC_ADC_POS1_MIN     820
#define HVAC_ADC_POS1_MAX     1638
#define HVAC_ADC_POS2_MIN     1639
#define HVAC_ADC_POS2_MAX     2457
#define HVAC_ADC_POS3_MIN     2458
#define HVAC_ADC_POS3_MAX     3276
#define HVAC_ADC_POS4_MIN     3277
#define HVAC_ADC_POS4_MAX     4095

#endif // HVAC_BSP_H